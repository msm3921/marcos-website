<?php

/*
Template Name: Home Page
*/ 


get_header(); ?>

<?php get_template_part ('template-parts/content','hero'); ?>

<?php get_template_part ('template-parts/content','optin'); ?>

<?php get_template_part ('template-parts/content','book'); ?>

<?php get_footer();

